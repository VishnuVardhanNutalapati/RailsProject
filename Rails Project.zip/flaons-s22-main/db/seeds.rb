user1 = User.create!(
    email: "alice@email.com",
    first_name: "alice",
    last_name: "alice",
    mobile_number: 38383838,
    password: "password",
    role: 0
)

user2 = User.create!(
    email: "admin@email.com",
    first_name: "bob",
    last_name: "bob",
    mobile_number: 38383838,
    password: "password",
    role: 2
)

category1=Category.create!(
    categoryname: 'beach'
)
category1.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/BEACH.jpg')), filename: 'BEACH.jpg' )

category2=Category.create!(
    categoryname: 'Trekking'
)
category2.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Trekking.JPG')), filename: 'Trekking.JPG' )

category3=Category.create!(
    categoryname: 'Camping'
)

category3.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Camping.jpg')), filename: 'Camping.jpg' )

category4=Category.create!(
    categoryname: 'Unique items in miami'
)

category4.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Unique items in miami.JPG')), filename: 'Unique items in miami.JPG' )


product1=Product.create!(
    productname: 'glasses',
    description: 'SOJOS Small Round Classic Polarized Sunglasses for Women Men Vintage Style UV400 Lens SJ2113',
    price: 14.99,
    highlights: 'SOJOS Small Round Classic Polarized Sunglasses for Women Men Vintage Style UV400 Lens SJ2113',
    quantity: 1,
    category: category1
)

product1.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/glasses.JPG')), filename: 'glasses.JPG' )

product2=Product.create!(
    productname: 'camera',
    description: 'Nikon D5600 Wi-Fi Digital SLR Camera with 18-55mm VR & 70-300mm DX AF-P Lenses with 32GB Card + Backpack + Flash + Tripod + Kit(Black)',
    price: 1089.8,
    highlights: 'KIT INCLUDES 10 PRODUCTS -- All BRAND NEW Items with all Manufacturer-supplied Accessories + Full USA Warranties',
    quantity: 1,
    category: category1
)

product2.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/camera.JPG')), filename: 'camera.JPG' )

product3=Product.create!(
    productname: 'Carry-on Weekend Bag',
    description: 'Travel Duffle Bags for Men Weekender Over Night Carry On Bag Lightweight Extra Large Oxford Duffel Gym Sturdy Luggage Water-proof for Men & Women 26" (Brown)',
    price: 30.99,
    highlights: 'Easy to carry and good space',
    quantity: 1,
    category: category1
)
product3.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Carry-on Weekend Bag.JPG')), filename: 'Carry-on Weekend Bag.JPG' )

product4=Product.create!(
    productname: 'Selfie Stick',
    description: 'Portable 40 Inch Aluminum Alloy Selfie Stick Phone Tripod with Wireless Remote Shutter Compatible with iPhone 13 12 11 pro Xs Max Xr X 8 7 6 Plus, Android Samsung Smartphone',
    price: 13.50,
    highlights: 'Portable',
    quantity: 1,
    category: category1
)
product4.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Selfie Stick.JPG')), filename: 'Selfie Stick.JPG' )

product5=Product.create!(
    productname: 'Portable Charger',
    description: 'Anker Portable Charger, 313 Power Bank (PowerCore Slim 10K) 10000mAh Battery Pack ',
    price: 30.5,
    highlights: 'with High-Speed PowerIQ Charging Technology and USB-C (Input Only) for iPhone, Samsung Galaxy, and More.(Black Color) ',
    quantity: 1,
    category: category1
)

product5.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Portable Charger.JPG')), filename: 'Portable Charger.JPG' )

product6=Product.create!(
    productname: 'Rain Jacket',
    description: ' Rain Jacket Waterproof(White)',
    price: 100.5,
    highlights: ' Rain Jacket Waterproof',
    quantity: 1,
    category: category1
)

product6.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Rain Jacket.JPG')), filename: 'Rain Jacket.JPG' )

product7=Product.create!(
    productname: 'Skin Cleaning Water',
    description: 'Garnier SkinActive Micellar Cleansing Water, For All Skin Types, 13.5 Fl Oz',
    price:5.99,
    highlights: 'Makeup Removal',
    quantity: 1,
    category: category1
)
product7.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Skin Cleaning Water.JPG')), filename: 'Skin Cleaning Water.JPG' )
product8=Product.create!(
    productname: 'Sun burn relief',
    description: 'Aloe Infusion Organic Aloe Vera Gel - 16 Oz',
    price: 7.99,
    highlights: ' Deeply Hydrating, Skin Nourishing After Sun Skin Care for Face, Body and Hair - Sunburn, Redness and Itchy Skin Relief - Made in the USA',
    quantity: 1,
    category: category1
)
product8.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Sun burn relief.JPG')), filename: 'Sun burn relief.JPG' )

product9=Product.create!(
    productname: 'Travel Toiletry bag',
    description: 'Toiletry Bag Travel Bag with Hanging Hook',
    price: 45,
    highlights: 'Water-resistant Makeup Cosmetic Bag Travel Organizer for Accessories, Shampoo, Full Sized Container, Toiletries',
    quantity: 1,
    category: category1
)
product9.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Travel Toiletry bag.JPG')), filename: 'Travel Toiletry bag.JPG' )

product10=Product.create!(
    productname: 'Waterproof Lining Beach Bag',
    description: 'Tote Bag, Beach Bag, Canvas Tote Bag, Nautical Beach Bag Tropical Bag, Beach Bag Hawaiian | Free Wristlet Included',
    price: 32.89,
    highlights: 'FASHION AND FUNCTION ',
    quantity: 1,
    category: category1
)
product10.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Waterproof Lining Beach Bag.JPG')), filename: 'Waterproof Lining Beach Bag.JPG' )

product11=Product.create!(
    productname: 'Wind proof Umbrella',
    description: 'Repel Umbrella Windproof Travel Umbrella',
    price: 14.99,
    highlights: 'Wind Resistant, Small - Compact, Light, Automatic, Strong, Mini, Folding and Portable - Backpack, Car, Purse Umbrellas for Rain - Men and Women',
    quantity: 1,
    category: category1
)
product11.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Wind proof Umbrella.JPG')), filename: 'Wind proof Umbrella.JPG' )


#Category2

product12=Product.create!(
    productname: 'Blister Balm',
    description: 'BodyGlide Foot Anti Blister Balm, 0.80 oz (USA Sale Only)',
    price: 6.5,
    highlights: 'Made with allergen free, plant-derived ingredients. Vegan approved, never tested on animals. Child safe',
    quantity: 1,
    category: category2
)

product12.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Blister Balm.JPG')), filename: 'Blister Balm.JPG' )

product13=Product.create!(
    productname: 'Camelbak Water Bottle',
    description: 'CamelBak Eddy+ Water Bottle with Tritan Renew – Straw Top',
    price: 19.80,
    highlights: 'Easy to Carry: Comfortable carry handle',
    quantity: 1,
    category: category2
)
product13.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Camelbak Water Bottle.JPG')), filename: 'Camelbak Water Bottle.JPG' )


product14=Product.create!(
    productname: 'Day Pack',
    description: 'Hiking Backpack 40L',
    price: 40.66,
    highlights: 'Waterproof Lightweight Hiking Daypack Trekking Camping Outdoor Sport Travel Backpacks for Men Women (Royal Red)',
    quantity: 1,
    category: category2
)
product14.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Day Pack.JPG')), filename: 'Day Pack.JPG' )

product15=Product.create!(
    productname: 'Hiking Pants',
    description: 'These are easy walkable',
    price: 10.5,
    highlights: 'black color',
    quantity: 1,
    category: category2
)
product15.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Hiking Pants.JPG')), filename: 'Hiking Pants.JPG' )

product16=Product.create!(
    productname: 'Neck Wallet',
    description: 'Water Resistant Outdoor Pants, Lightweight Stretch Cargo/Straight Work Pants, UPF 50+ Outdoor Apparel',
    price: 32.9,
    highlights: 'Outdoor Adventure Pants© Series designed for all outdoor activities and sports.',
    quantity: 1,
    category: category2
)
product16.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Neck Wallet.JPG')), filename: 'Neck Wallet.JPG' )

product17=Product.create!(
    productname: 'Trail Snacks',
    description: 'Chocolate Raisin Nut Trail Mix,2 Ounce Bags (Pack of 14), Dark Chocolate Covered Raisins, Almonds, and Peanuts, Gluten Free, Non-GMO',
    price: 10.5,
    highlights: 'pure and simple nuts and dried sweetened fruit that support your active lifestyle',
    quantity: 1,
    category: category2
)
product17.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Trail Snacks.JPG')), filename: 'Trail Snacks.JPG' )

product18=Product.create!(
    productname: 'Wool Socks',
    description: 'Mens Merino Wool Hiking Cushion',
    price: 8.88,    
    highlights: 'Mens Merino Wool Hiking Cushion',
    quantity: 1,
    category: category2
)
product18.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Wool Socks.JPG')), filename: 'Wool Socks.JPG' )

product19=Product.create!(
    productname: 'Bandana',
    description: '12 Pack(one Dozen) Multi-Purpose Cotton Paisley Cowboy Bandanas',
    price: 11.7,
    highlights: 'Wash by Hand with Cold Water and Mild Soap.Hand Dry to Keep Its Shape',
    quantity: 1,
    category: category2
)
product19.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Bandana.JPG')), filename: 'Bandana.JPG' )

product20=Product.create!(
    productname: 'Hiking Boots',
    description: ' Merrel Ridge Plus Ii Waterproof Hiking Shoe',
    price: 49.5,
    highlights: 'Merrel Ridge Plus II Waterproof Hiking Boot features a lace-up closure for an adjustable, secure fit.',
    quantity: 1,
    category: category2
)
product20.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Hiking Boots.JPG')), filename: 'Hiking Boots.JPG' )

product21=Product.create!(
    productname: 'Headlamp',
    description: 'Flashlight Headlamps w/ Adjustable Headband for Adults and Kids - Hiking & Camping Gear',
    price: 19.5,
    highlights: 'Weather Resistant - Water resistant and shockproof, the S500 headlamp flashlight is suitable for rain or snow, indoors or outdoors. Add it to the top of your running, hiking and camping accessories list!',
    quantity: 1,
    category: category2
)
product21.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Headlamp.JPG')), filename: 'Headlamp.JPG' )


#Category3

product22=Product.create!(
    productname: 'aqua-packing-cubes-120',
    description: 'Veken 6 Set Packing Cubes, Travel Luggage Organizers with Laundry Bag & Shoe Bag (Teal)',
    price: 21.99,
    highlights: 'black colorSuitable for every occasion. These packing cubes can help to reduce clothing wrinkles by preventing movement inside the suitcase. Imagine 1 piece of luggage for every item, or use one packing cube per group and compress them all in one bag. Ideal for family vacations, business trips, outdoor camping, and daily storage.',
    quantity: 1,
    category: category3
)
product22.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/aqua-packing-cubes-120.JPG')), filename: 'aqua-packing-cubes-120.JPG' )

product23=Product.create!(
    productname: 'Baby-Bum-Hand-Sanitizer',
    description: 'Baby Bum Everyday Lotion | Moisturizing Baby Body Lotion for Sensitive Skin with Shea and Cocoa(pack 3)',
    price: 10.5,
    highlights: 'Aerosol',
    quantity: 1,
    category: category3
)
product23.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Baby-Bum-Hand-Sanitizer.JPG')), filename: 'Baby-Bum-Hand-Sanitizer.JPG' )

product24=Product.create!(
    productname: 'Camping-stove',
    description: 'Coleman Gas Camping Stove | Triton Propane Stove, 2 Burner',
    price: 89.5,
    highlights: 'EASY TO CLEAN: Chrome-plated grate and rust-resistant aluminum cooktop color',
    quantity: 1,
    category: category3
)
product24.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Camping-stove.JPG')), filename: 'Camping-stove.JPG' )

product25=Product.create!(
    productname: 'Cooler-for-camping',
    description: 'Coleman Xtreme Portable Cooler | Hard Cooler Keeps Ice Up to 5 Days(Black Color)',
    price: 122.89,
    highlights: 'Xtreme Technology; Insulated lid and extra wall insulation keep ice up to 5 days in temperatures as high as 90°F',
    quantity: 1,
    category: category3
)
product25.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Cooler-for-camping.JPG')), filename: 'Cooler-for-camping.JPG' )

product26=Product.create!(
    productname: 'deoderant-wipes',
    description: 'Go Fresh Deodorant Wipes Cucumber & Green Tea, 75 Count, Pack of 3',
    price: 10.5,
    highlights: 'Pair your new wipes with Dove cool Essentials antiperspirant Deodorant for women to stay fresh and protected all day long',
    quantity: 1,
    category: category3
)
product26.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/deoderant-wipes.JPG')), filename: 'deoderant-wipes.JPG' )

product27=Product.create!(
    productname: 'first-aid-kit',
    description: 'Compact First Aid Kit (228pcs) Designed for Family Emergency Care.',
    price: 12.5,
    highlights: 'Waterproof EVA Case and Bag is Ideal for The Car, Home, Boat, School, Camping, Hiking, Office, Sports. Protect Your Loved Ones.',
    quantity: 1,
    category: category3
)
product27.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/first-aid-kit.JPG')), filename: 'first-aid-kit.JPG' )

product28=Product.create!(
    productname: 'Hammock',
    description: 'Outfitters Camping Hammock - Portable Hammock Single or Double Hammock Camping Accessories for Outdoor, Indoor w/ Tree Straps',
    price: 17.5,    
    highlights: 'Premium Quality: Built to last a lifetime, our heavy-duty hammocks for camping are crafted with soft yet strong parachute nylon and triple interlocking stitching, along with strong carabiners and tree friendly hammock straps. Our hammocks are machine washable ',
    quantity: 1,
    category: category3
)
product28.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Hammock.JPG')), filename: 'Hammock.JPG' )

product29=Product.create!(
    productname: 'Lifestraw-Water-Bottle',
    description: 'elf-Cleaning and Insulated Stainless Steel Water Bottle',
    price: 45.5,
    highlights: 'elf-Cleaning and Insulated Stainless Steel Water Bottle',
    quantity: 1,
    category: category3
)
product29.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Lifestraw-Water-Bottle.JPG')), filename: 'Lifestraw-Water-Bottle.JPG' )

product30=Product.create!(
    productname: 'Sleeping-Bag',
    description: 'Sleeping Bags for Adults & Kids - Ultralight Backpacking Sleeping Bag for Hiking Cold Weather & Warm',
    price: 29.99,
    highlights: 'Enjoy high-quality double-sided zippers that are snag-free and super satisfying to use. Tug those drawstrings in the headrest to bring the bag a little closer to your head for extra warmth in colder weather. ',
    quantity: 1,
    category: category3
)
product30.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Sleeping-Bag.JPG')), filename: 'Sleeping-Bag.JPG' )

product31=Product.create!(
    productname: 'Solar-charger-with-flashlight',
    description: 'Solar Power Bank, Qi Portable Charger 10,000mAh External Battery Pack Type C Input Port Dual Flashlight,',
    price: 88.59,
    highlights: 'the portable charger is made of premium ABS materials and lithium polymer battery, highly sturdy and durable. Its equipped with two USB, type C, dual flashlights and a compass kit. Light weight and compact size.',
    quantity: 1,
    category: category3
)
product31.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Solar-charger-with-flashlight.JPG')), filename: 'Solar-charger-with-flashlight.JPG' )

product32=Product.create!(
    productname: 'Tent-for-camping',
    description: 'Camping Tent 6 Person Family Dome Tent with Removable Rain Fly, Easy Setup for Camp Backpacking Hiking Outdoor , Green',
    price: 38.5,
    highlights: 'There are two mesh storage bags and a net bag on the top in the easy up tent and keep the dome tent organized. The hook on the top designed for a lantern. E-Port makes it easy to bring electrical power inside',
    quantity: 1,
    category: category3
)
product32.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Tent-for-camping.JPG')), filename: 'Tent-for-camping.JPG' )

#category4
product33=Product.create!(
    productname: 'alligator taxidermy products',
    description: 'While you might not want to take home an alligator, you can take back some rather unusual alligator products that will remind you of the deadly predator of Florida.',
    price: 100.5,
    highlights: 'you will find something that will be almost as unique as the colossal Everglades!',
    quantity: 1,
    category: category4
)
product33.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/alligator taxidermy products.JPG')), filename: 'alligator taxidermy products.JPG' )

product34=Product.create!(
    productname: 'art deco posters',
    description: 'The Art Deco style of architecture and Miami Beach are an inseparable combination, much like Miamians and their café con leche',
    price: 10.5,    
    highlights: ' Defining the character of Miami Beach, this extravagant style of architecture inspires a sense of decadent leisure.    ',
    quantity: 1,
    category: category4
)
product34.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/art deco posters.JPG')), filename: 'art deco posters.JPG' )

product35=Product.create!(
    productname: 'lime products',
    description: 'The oh-so-fragrant key lime is the fruit mascot of Florida.',
    price: 11.5,
    highlights: ' Ranging from Key Lime BBQ Sauce with Ginger, Key Lime Cookies, Key Lime Savory Oil to Key Lime Syrup, you can get them all. No matter which key lime flavored edible gift you take back, this will be one gift that will make the flavor of Miami linger.',
    quantity: 1,
    category: category4
)
product35.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/lime products.JPG')), filename: 'lime products.JPG' )

product36=Product.create!(
    productname: 'local jams',
    description: ' In Miami, you will find a range of exotic fruit jams, preserves and honey that will transform your regular slice of bread or bagel into a gourmet affair. From honeybell preserves and vidalia onion sweet relish to key lime, amaretto or wildflower honey, you will find something to satisfy everyone’s sweet craving.',
    price: 10.5,
    highlights: 'Happily, these sweet delights are easy to carry and easy to find. ',
    quantity: 1,
    category: category4
)
product36.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/local jams.JPG')), filename: 'local jams.JPG' )

product37=Product.create!(
    productname: 'miccosukee crafts',
    description: 'These plethora of handcrafted products made by the Miccosukee Tribe of Florida ',
    price: 3.59,
    highlights: 'They are tiny pieces of living history.',
    quantity: 1,
    category: category4
)
product37.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/miccosukee crafts.JPG')), filename: 'miccosukee crafts.JPG' )

ad1 = Ad.create!(
    companyname: 'UberEats',
    description: 'A world of customers now within your reach, Ubers global platform gives you the flexibility, visibility and customer insights you need to connect with more customers. Partner with us today.',
    websiteurl: 'https://www.ubereats.com/'
)
ad1.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/UberEats_ad_2.JPG')), filename: 'UberEats_ad_2.JPG' )

ad2 = Ad.create!(
    companyname: 'Amazon',
    description: 'Amazon.com, Inc. is an American multinational technology company which focuses on e-commerce, cloud computing, digital streaming, and artificial intelligence. It has been referred to as one of the most influential economic and cultural forces in the world, and is one of the worlds most valuable brands',
    websiteurl: 'https://www.amazon.com/'
)
ad2.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/amazon_ad.JPG')), filename: 'amazon_ad.JPG' )

blog1 = Blog.create!(
  name: 'The Wordy Girl | Miami’s designer fashion blogger',
  description: ('Miami’s top designer fashion blogger. Thewordygirl is a funny blog about serious fashion, luxe travel (Maldives, anyone?) and highbrow beauty.')
)
blog1.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/eater.jpg')), filename: 'eater.jpg' )

blog2 = Blog.create!(
  name: 'Art News Blog',
  description: ('Lightheflame presents the much anticipated opening of ‘Victorious Tears’ at Temple Emanu-El on Miami Beach, a provocative and pivotal art exhibition exploring changing values on two continents through established and emerging artists in South Africa and America. Artists like Asanda Kupa, Cassius Khumalo and Lawrence Chikwa, fast-rising in the Contemporary African Art scene, show us the vibrance of Africa and magic of ritual. Art aficionados and collectors are cordially invited to experience the Opening Reception of ‘Victorious Tears’ on Wednesday, April 20th at 6pm. Temple Emanu-El is located at 1701 Washington Avenue, Miami Beach 33139 – Exhibition entrance is on 17th Street.'))

blog2.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/Art.jpg')), filename: 'Art.jpg' )

blog3 = Blog.create!(
  name: 'Eater Miami',
  description: ('The bar at Dirty French. Kris Tamburello Major Food Group’s first Brickell restaurant features plenty of animal print, gold-leaf ceilings, and a disco ball themed room. Brickell is the latest neighborhood in Miami to welcome a Major Food Group restaurant with the debut of Dirty French Steakhouse, an opulent and purposely over-the-top steakhouse.

  Taking over the former Morton’s location in Brickell, the New York City import features decor that is distinctly Miami. The space has been completely redone by longtime MFG collaborator Ken Fulk. Guests enter Dirty French Steakhouse through the Jungle Bar, a lounge draped in tropical leaf patterns with a gold-leafed ceiling, a heroic onyx bar, Murano glass leaf chandelier, fringed leopard bar stools, golden banana leaf pendants hanging overhead, and solid green marble cocktail tables.'))

blog3.figure_image.attach(io: File.open(Rails.root.join('app/assets/images/fashion.jpg')), filename: 'fashion.jpg' )

