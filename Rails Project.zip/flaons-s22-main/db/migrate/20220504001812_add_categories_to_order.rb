class AddCategoriesToOrder < ActiveRecord::Migration[6.1]
  def change
    add_column :orders, :categories, :string, array: true, default: []
  end
end
