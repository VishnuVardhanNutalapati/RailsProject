class AddProductsToOrder < ActiveRecord::Migration[6.1]
  def change
    add_column :orders, :products, :string, array: true, default: []
  end
end
