class CreateAds < ActiveRecord::Migration[6.1]
  def change
    create_table :ads do |t|
      t.string :companyname
      t.string :websiteurl
      t.text :description

      t.timestamps
    end
  end
end
