class CreateProducts < ActiveRecord::Migration[6.1]
  def change
    create_table :products do |t|
      t.string :productname
      t.string :description
      t.decimal :price
      t.string :highlights
      t.integer :quantity

      t.timestamps
    end
  end
end
