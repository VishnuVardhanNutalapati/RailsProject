# == Schema Information
#
# Table name: orders
#
#  id          :bigint           not null, primary key
#  address     :string
#  cardnumber  :string
#  carttotal   :decimal(, )
#  categories  :string           default([]), is an Array
#  city        :string
#  expirydate  :string
#  name        :string
#  nameoncard  :string
#  ordereddate :date
#  phonenumber :string
#  products    :string           default([]), is an Array
#  state       :string
#  uemail      :string
#  zipcode     :string
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#
require "test_helper"

class OrderTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
