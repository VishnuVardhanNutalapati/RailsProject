# == Schema Information
#
# Table name: ads
#
#  id          :bigint           not null, primary key
#  companyname :string
#  description :text
#  websiteurl  :string
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#
require "test_helper"

class AdTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
