# == Schema Information
#
# Table name: returns
#
#  id         :bigint           not null, primary key
#  comment    :string
#  created_at :datetime         not null
#  updated_at :datetime         not null
#
require "test_helper"

class ReturnTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
