Rails.application.routes.draw do
  devise_for :users, :controllers => { registrations: 'users/registrations' }
  root to: redirect('/categories')
  get 'categories', to: 'categories#home', as: 'home'
  get 'cart', to: 'pages#cart', as: 'cart'
  post 'categories', to: 'categories#create'
  get 'categories/new', to: 'categories#new', as: 'new_category'
  get 'categories/:category_id/products/newproduct', to: 'products#new', as: 'new_category_product'
  post 'categories/:category_id/products', to: 'products#create'
  get 'categories/:category_id/products', to: 'products#index', as: 'category_products'
  get 'categories/:category_id/products/:id', to: 'products#show', as: 'category_product'
  patch 'categories/:category_id/products/:id', to: 'products#update'
  delete 'categories/:category_id/products/:id', to: 'products#destroy'
  put 'categories/:category_id/products/:id', to: 'products#update'
  get 'categories/:category_id/products/:id/edit', to: 'products#edit', as: 'edit_category_product'
  
  
  get 'blogs', to: 'blogs#index', as: 'blogs'
  post 'blogs', to: 'blogs#create'
  get 'blogs/new', to: 'blogs#new', as: 'new_blog'
  get 'blogs/:id', to: 'blogs#show', as: 'blog'
  patch 'blogs/:id', to: 'blogs#update'
  delete 'blogs/:id', to: 'blogs#destroy'
  get 'blogs/:id/edit', to: 'blogs#edit', as: 'edit_blog'
  
  delete 'categories/:category_id/products/:id/remove_from_cart', to: 'products#remove_from_cart', as: 'remove_from_cart'
  post 'categories/:category_id/products/:id/add_to_cart', to: 'products#add_to_cart', as: 'add_to_cart'

  get 'checkout', to: 'pages#checkout', as: 'checkout'
  post 'checkout', to: 'pages#create'
  get 'transactions', to: 'pages#transactions', as: 'transactions'
  get 'transaction/:id', to: 'pages#transaction', as: 'transaction'
  delete 'transaction/:id', to: 'pages#destroy'
  
 
  get 'ads', to: 'ads#index', as: 'ads'
  post 'ads', to: 'ads#create'
  get 'ads/new', to: 'ads#new', as: 'new_ad'
  get 'ads/:id', to: 'ads#show', as: 'ad'
  patch 'ads/:id', to: 'ads#update'
  delete 'ads/:id', to: 'ads#destroy'
  get 'ads/:id/edit', to: 'ads#edit', as: 'edit_ad'

  get 'categories/:category_id/products/:id/reviews/new', to: 'reviews#new', as: 'new_review'
  post 'categories/:category_id/products/:id/reviews', to: 'reviews#create', as: 'create_review'
  get 'categories/:category_id/products/:id/reviews', to: 'reviews#show', as: 'show_reviews'

  get 'return', to: 'return#new', as:'new_return'
  post 'return', to: 'return#create', as: 'return'

end
