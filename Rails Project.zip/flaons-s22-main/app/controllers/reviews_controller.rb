class ReviewsController < ApplicationController
  before_action :authenticate_user!, except: [:show]
    def new
        @category=Category.find(params[:category_id])
        @product =@category.products.find(params[:id])
        @review = Review.new
        render :new
    end

    def create
        @category=Category.find(params[:category_id])
        @product =@category.products.find(params[:id])
        @review = Review.new(params.require(:review).permit(:product, :rating, :comment))
        if @review.save
          flash[:success] = "Review saved successfully"
          redirect_to category_product_url(@category,@product)
        else
          flash.now[:error] = "Review could not be saved"
          render :new
        end
    end

    def show
        @category=Category.find(params[:category_id])
        @product =@category.products.find(params[:id])
        @reviews=Review.all
        render :show
    end

end
