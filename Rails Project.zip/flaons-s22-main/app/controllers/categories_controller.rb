class CategoriesController < ApplicationController
    before_action :check_is_admin?, except: [:home]

    def home
        @Category=Category.all
        render :home
    end

    def new
        @category = Category.new
        render :new
    end

    def create
        @category = Category.new(params.require(:category).permit(:categoryname, :figure_image))
        if @category.save
            flash[:success] = "New category created succuessfully!"
            redirect_to home_url
        else
            flash.now[:error] = "Category creation failed"
            render :new
        end
    end
end
