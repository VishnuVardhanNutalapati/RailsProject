class BlogsController < ApplicationController
    before_action :check_is_admin?, except: [:index, :show]

    def index
        @blogs = Blog.all
        render :index
    end

    def show
        @blog = Blog.find(params[:id])
        render :show
    end
    def new
        @blog = Blog.new
        render :new
    end

    def create
        @blog = Blog.new(params.require(:blog).permit(:name, :figure_image, :description))
        if @blog.save
            flash[:success] = "New blog successfully created!"
            redirect_to blogs_url
        else
            flash.now[:error] = "blog creation failed"
            render :new
        end
    end

    def edit
        @blog = Blog.find(params[:id])
        render :edit
    end

    def update
        @blog = Blog.find(params[:id])
        if @blog.update(params.require(:blog).permit(:name, :figure_image, :description))
          flash[:success] = "Blog successfully updated!"
          redirect_to blog_url(@blog)
        else
          flash.now[:error] = "Blog update failed"
          render :edit
        end
    end

    def destroy
        @blog = Blog.find(params[:id])
        @blog.destroy
        flash[:success] = "The to-do item was successfully destroyed."
        redirect_to blogs_url
    end

end
