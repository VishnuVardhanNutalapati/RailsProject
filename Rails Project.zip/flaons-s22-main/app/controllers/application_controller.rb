class ApplicationController < ActionController::Base
    before_action :initialize_session
    before_action :load_cart
    before_action :show_ads

    private

    def initialize_session
        session[:cart]||=[]
    end

    def load_cart
        @cart= Product.find(session[:cart])
    end

    def show_ads
        @ads = Ad.all
    end

    private
    def show_ads
        @ads = Ad.all
    end

    def check_is_admin?
        if current_user == nil || !current_user.admin?
          redirect_to home_path
        end
    end

end
