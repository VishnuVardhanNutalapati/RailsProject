class AdsController < ApplicationController
    before_action :check_is_admin?

    def index
        @ads = Ad.all
        render :index
    end

    def show
        @ad = Ad.find(params[:id])
        render :show
    end

    def new
        @ad = Ad.new
        render :new
    end

    def create
        @ad = Ad.new(params.require(:ad).permit(:companyname, :websiteurl, :description, :figure_image))
        if @ad.save
            flash[:success] = "New Ad successfully added!"
            redirect_to ads_url
        else
            flash.now[:error] = "Ad creation failed"
            render :new
        end
    end

    def edit
        @ad = Ad.find(params[:id])
        render :edit
    end

    def update
        @ad = Ad.find(params[:id])
        if @ad.update(params.require(:ad).permit(:companyname, :websiteurl, :description, :figure_image))
            flash[:success] = "Ad successfully updated!"
            redirect_to ad_url(@ad)
        else
            flash.now[:error] = "Ad update failed"
            render :edit
        end
    end

    def destroy
        @ad = Ad.find(params[:id])
        @ad.destroy
        flash[:success] = "The Ad was successfully destroyed."
        redirect_to ads_url
    end

end
