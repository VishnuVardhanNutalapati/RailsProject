class ReturnController < ApplicationController
    def new
        @return=Return.new
        render :new
    end
    
    def create
        @return = Return.new(params.require(:return).permit(:comment))
        if @return.save
            flash[:success] = "Your return has been submitted"
            redirect_to home_url
        else
            flash.now[:error] = "Return request cannot be processed"
            render :new
        end
    end
end
