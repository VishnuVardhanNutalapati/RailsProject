class PagesController < ApplicationController
    before_action :authenticate_user!
    def cart
        render :cart
    end
    
    def checkout
        @order=Order.new
        render :checkout
    end
    
    def create
        @order=Order.new(params.require(:order).permit(:name, :address, :city, :state, :zipcode, :phonenumber, :nameoncard, :cardnumber, :expirydate, :carttotal, :ordereddate, :uemail, products: [], categories: []))
        if @order.save
            flash[:success] = "Your order has been placed"
            session[:cart]=[]
            redirect_to home_url
        else
            flash.now[:error] = "Payment failed please try again!"
            render :checkout
        end
    end

    def transactions
        @orders=Order.all
        render :transactions
    end

    def transaction
        @order=Order.find(params[:id])
        render :transaction
    end
    
    def destroy
        @order=Order.find(params[:id])
        @order.destroy
        flash[:success] = "Transaction deleted."
        redirect_to transactions_url
    end
   
end
