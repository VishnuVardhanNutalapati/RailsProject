class ProductsController < ApplicationController
  before_action :check_is_admin?, except: [:index, :show, :add_to_cart, :remove_from_cart]
  before_action :authenticate_user!, except: [:index, :show]

    def index
        @cat=Category.find(params[:category_id])
        @products=@cat.products
        render :index
    end

    def show
        @category = Category.find(params[:category_id])
        @product = @category.products.find(params[:id])
        render :show
    end

    def new
        @category=Category.find(params[:category_id])
        @product=Product.new
        render :new
    end

    def create
        @category = Category.find(params[:category_id])
        @product = @category.products.build(params.require(:product).permit(:productname, :figure_image, :description, :price, :highlights, :quantity))
        if @product.save
          flash[:success] = "New product created successfully"
          redirect_to category_products_url(@category)
        else
          flash.now[:error] = "New product creation failed"
          render :new
        end
    end
      
    def edit
        @category = Category.find(params[:category_id])
        @product = @category.products.find(params[:id])
        render :edit
    end

    def update
      @category = Category.find(params[:category_id])
      @product = @category.products.find(params[:id])
      if @product.update(params.require(:product).permit(:productname, :figure_image, :description, :price, :highlights, :quantity))
        flash[:success] = "Product updated successfully"
        redirect_to category_product_url(@category, @product)
      else
        flash.now[:error] = "Product could not be updated, Please try again"
        render :edit
      end
    end

    def destroy
      @category = Category.find(params[:category_id])
      @product = @category.products.find(params[:id])
      @product.destroy
      flash[:success] = "Product has been removed"
      redirect_to category_products_url(@category)
    end


    def add_to_cart
      @category=Category.find(params[:category_id])
      @product=@category.products.find(params[:id])
      p_id=@product.id
      session[:cart]<< p_id unless session[:cart].include?(p_id)
      redirect_to category_product_url(@category,@product)
    end

    def remove_from_cart
      @category=Category.find(params[:category_id])
      @product=@category.products.find(params[:id])
      p_id=@product.id
      session[:cart].delete(p_id)
      redirect_to cart_url
    end
end
