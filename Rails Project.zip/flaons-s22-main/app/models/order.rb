# == Schema Information
#
# Table name: orders
#
#  id          :bigint           not null, primary key
#  address     :string
#  cardnumber  :string
#  carttotal   :decimal(, )
#  categories  :string           default([]), is an Array
#  city        :string
#  expirydate  :string
#  name        :string
#  nameoncard  :string
#  ordereddate :date
#  phonenumber :string
#  products    :string           default([]), is an Array
#  state       :string
#  uemail      :string
#  zipcode     :string
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#
class Order < ApplicationRecord
    validates :address, presence: true
    validates :cardnumber, presence: true
    validates :categories, presence: true
    validates :city, presence: true
    validates :expirydate, presence: true
    validates :name, presence: true
    validates :nameoncard, presence: true
    validates :ordereddate, presence: true
    validates :phonenumber, presence: true
    validates :state, presence: true
    validates :zipcode, presence: true 
end
