# == Schema Information
#
# Table name: returns
#
#  id         :bigint           not null, primary key
#  comment    :string
#  created_at :datetime         not null
#  updated_at :datetime         not null
#
class Return < ApplicationRecord
end
