# == Schema Information
#
# Table name: products
#
#  id          :bigint           not null, primary key
#  description :string
#  highlights  :string
#  price       :decimal(, )
#  productname :string
#  quantity    :integer
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#  category_id :bigint
#
# Indexes
#
#  index_products_on_category_id  (category_id)
#
# Foreign Keys
#
#  fk_rails_...  (category_id => categories.id)
#
class Product < ApplicationRecord
    belongs_to(
        :category,
        class_name: 'Category',
        foreign_key: 'category_id',
        inverse_of: :products
    )
    has_one_attached :figure_image
    validates :productname, presence: true
    validates :description, presence: true
    validates :highlights, presence: true
    validates :price, presence: true
    validates :quantity, presence: true
end


