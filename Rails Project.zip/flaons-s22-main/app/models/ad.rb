# == Schema Information
#
# Table name: ads
#
#  id          :bigint           not null, primary key
#  companyname :string
#  description :text
#  websiteurl  :string
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#
class Ad < ApplicationRecord
    has_one_attached :figure_image
    validates :companyname, presence: true
    validates :description, presence: true
    validates :websiteurl, presence: true
    
   
end
